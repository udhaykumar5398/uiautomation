import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import _store from "./Store";
const { persistor,Store } = _store();

// Debug logging
console.log('Persistor:', persistor);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  // <React.StrictMode>
    <Router>
      <PersistGate persistor={persistor}>
        <Provider store={Store}>
          <App />
        </Provider>
      </PersistGate>
    </Router>
  // </React.StrictMode>
);

reportWebVitals();
