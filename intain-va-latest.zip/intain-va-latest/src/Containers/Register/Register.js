/* eslint-disable max-len */
/* eslint-disable require-jsdoc */
import React, { useState, useEffect } from 'react';
import Button from '@material-ui/core/Button';
import { withTheme } from 'react-jsonschema-form';
import { Theme as MuiTheme } from 'rjsf-material-ui';
import LinkItem from '../../Components/LinkItem/linkitem';
import { useDispatch } from 'react-redux';
import { CustomFieldTemplate, widgets } from '../../Components/CustomScripts/CustomScript';
import { register } from '../../Store/User/UserAction';

const Form = withTheme(MuiTheme);
const schema = require('./schema.json');
const uiSchema = {
    email: {
        'ui:widget': 'email',
    },
    password: {
        'ui:widget': 'password',
    },
};

const Register = ({ enqueueSnackbar, history }) => {
    const dispatch=useDispatch();
    const [formSchema, setFormSchema] = useState(schema);
    const [formData, setFormData] = useState({});
    const [formLoader, setFormLoader] = useState(false);
    const token = localStorage.getItem('token');
    const peers = JSON.parse(localStorage.getItem('peers'));
    const userid = localStorage.getItem('userid');

    const validate = (formData, errors) => {
        if (!formData.password.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/)) {
            errors.password.addError(
                'Password should contain 1 uppercase, 1 numeric, 1 special character & at least 8 characters'
            );
        }
        return errors;
    };

    useEffect(() => {
        localStorage.clear();

    }, []);

    const onSubmit = async (value) => {
        console.log('onSubmit:', value.formData);
        const data = value.formData;
        await dispatch(register(data))
        console.log(data)



    };

    return (
        <React.Fragment>
            <div style={{ display: "flex", flexDirection: "column" }}>
                <h4>Sign up to your account to access Intain ABS</h4>
                <div className="form_row_single">
                    {/* formLoader can be used here to conditionally show loader */}
                    <Form
                        schema={formSchema}
                        // onChange={formData}
                        onSubmit={onSubmit}
                        widgets={widgets}
                        FieldTemplate={CustomFieldTemplate}
                        uiSchema={uiSchema}
                        // validate={validate}
                    >
                        <div id="form-btn">
                            <div className="container-fluid text-center">
                                <div className="row">
                                    <Button
                                        className="col-md-12"
                                        variant="contained"
                                        size="large"
                                        color="primary"
                                        id="signinbutton"
                                        type="submit"
                                        disabled={formLoader}
                                        style={{background:"#048c88"}}
                                    >
                                        Register
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </Form>
                    <div className="loginCheckbox">
                        <p className="lineDivider">
                            <span>Have Account?</span>
                        </p>
                        <LinkItem to={'/'} variant="contained" className="loginBtn" title={'Login'}> </LinkItem>
                    </div>
                </div></div>
        </React.Fragment>
    );
};

export default Register
