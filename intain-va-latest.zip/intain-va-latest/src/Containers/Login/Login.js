import React, { useEffect, useState } from 'react';
import "./Login.css";
import FormLoader from '../../Components/Formloader/Formloader';
import { useForm, Controller } from 'react-hook-form';
import LinkItem from '../../Components/LinkItem/linkitem';
import CustomButton from '../../Components/Buttons/CustomButton';
import CustomTextField from '../../Components/TextField/TextField';
import {
  TextField, MenuItem, Button, Dialog, IconButton,
  DialogTitle, Checkbox, FormControlLabel,
  DialogContent, DialogActions, Typography, FormHelperText
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { forgotPassword, jwttoken } from '../../Store/User/UserAction';
import { withTheme } from "react-jsonschema-form";
import { Theme as MuiTheme } from "rjsf-material-ui";
import { CustomFieldTemplate, widgets } from '../../Components/CustomScripts/CustomScript';
const Form = withTheme(MuiTheme);
const schema = require("./schema.json");
const uiSchema = {
  email: {
    "ui:widget": "email",
  },
  password: {
    "ui:widget": "password",
  },
};


const LoginPage = () => {
  const { control: resetControl, handleSubmit: handleResetSubmit, formState: { errors: resetErrors } } = useForm();
  const [keepSignedIn, setKeepSignedIn] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    emailid: "",
    password: "",
    userrole: "",
  });
  const [orgLoading, setOrgLoading] = useState(false);


  const onSubmit = async (data) => {
    console.log(data);
    await jwttoken(data.formData);



    // Handle form submission here (e.g., send data to an API)
  };

  const handleForgotPasswordOpen = () => {
    setOpenDialog(true);
  };

  const handleForgotPasswordClose = () => {
    setOpenDialog(false);
  };

  const handlePasswordResetSubmit = async (data) => {
    console.log(data, 'forgotPassword');
    await forgotPassword(data)
    // Handle password reset logic here
    setOpenDialog(false)
  };

  const handleKeepSignedInChange = (event) => {
    setKeepSignedIn(event.target.checked);
  };

  useEffect(() => {

    localStorage.clear()
  }, [])
  return (
    <>
      <div style={{ display: "flex", flexDirection: "column" ,width:"40rem"}}>
        {loading && <FormLoader />}
        <h4>Log in to your account to access Intain ABS</h4>


        <div className="form_row_single">
        {/* {orgLoading === false ?(
  <FormLoader></FormLoader>
):(
  
)} */}
          <Form
            schema={schema}
            formData={formData}
            onSubmit={onSubmit}
            widgets={widgets}
            FieldTemplate={CustomFieldTemplate}
            uiSchema={uiSchema}
          >
            <div id="form-btn">
              <div className="container-fluid" style={{ textAlign: "center" }}>
                <div className="row">
                  <Button
                    className="col-md-12"
                    variant="contained"
                    size="large"
                    color="primary"
                    id="signinbutton"
                    type="submit"
                  >
                    Sign In
                  </Button>
                </div>
                <div>
                  <div
                    type='button'
                    className='popupcancelbtn'
                    onClick={handleForgotPasswordOpen}
                  >
                    Forgot Password?
                  </div>
                </div>
              </div>
            </div>
          </Form>

          <FormControlLabel
            control={
              <Checkbox
                checked={keepSignedIn}
                onChange={handleKeepSignedInChange}
                color="primary"
              />
            }
            label="Keep me signed-in"
          />
          <div style={{ display: 'flex', alignItems: 'center', marginTop: '35px' }}>
            <hr style={{ flex: 1, border: '1px solid #ccc', marginRight: '8px' }} />
            <Typography variant="body2" color="textSecondary" style={{ whiteSpace: 'nowrap' }}>
              New to Intain ABS?
            </Typography>
            <hr style={{ flex: 1, border: '1px solid #ccc', marginLeft: '8px' }} />
          </div>
          <LinkItem
            to={"/register"}
            variant="contained"
            className="loginBtn"
            title={"Create your Account"}
          >
          </LinkItem>

        </div>
        <Dialog open={openDialog} onClose={handleForgotPasswordClose} className='modalPopup'>
          <div >
            <h2>Forgot Password</h2>
            <>

              <IconButton
                edge="end"
                color="inherit"
                onClick={handleForgotPasswordClose}
                aria-label="close"
                style={{ position: 'absolute', right: 16, top: 8, color: "#018e82" }}
              >
                <CloseIcon />
              </IconButton>
            </>
            <DialogContent>
              <Typography variant="body1" gutterBottom>
                Confirm your Mail ID
              </Typography>
              <Typography variant="body2" gutterBottom>
                We will send the link to reset your password on your registered mail ID
              </Typography>
              <Controller
                name="emailid"
                control={resetControl}
                defaultValue=""
                rules={{ required: 'Email is required' }}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Email ID"
                    variant="filled"
                    fullWidth
                    error={!!resetErrors.emailid}
                    helperText={resetErrors.emailid ? resetErrors.emailid.message : ''}
                    style={{ marginBottom: '16px' }}
                  />
                )}
              />
              <Controller
                name="userrole"
                control={resetControl}
                defaultValue=""
                rules={{ required: 'User role is required' }}
                render={({ field }) => (
                  <TextField
                    {...field}
                    select
                    label="User Role"
                    variant="filled"
                    fullWidth
                    error={!!resetErrors.userrole}
                    helperText={resetErrors.userrole ? resetErrors.userrole.message : ''}
                    style={{ marginBottom: '16px' }}
                  >
                    <MenuItem value="Admin">Admin</MenuItem>
                    <MenuItem value="Processor">Processor</MenuItem>
                  </TextField>
                )}
              />
            </DialogContent>
            <DialogActions style={{ marginRight: "15px", marginBottom: "5px" }}>
              <Button className='popupcancelbtn' onClick={handleForgotPasswordClose} color="primary" variant='outlined'>
                Cancel
              </Button>
              <CustomButton
                variant="contained"
                color="primary"
                onClick={handleResetSubmit(handlePasswordResetSubmit)}
              >
                Confirm
              </CustomButton>
            </DialogActions>
          </div>
        </Dialog>
      </div>

    </>
  );
};

export default LoginPage;
// import React, { useState } from 'react';
// import { withTheme } from "react-jsonschema-form";
// import { Theme as MuiTheme } from "rjsf-material-ui";
// import { CustomFieldTemplate, widgets } from '../../Components/CustomScripts/CustomScript'
// import FormLoader from "../../Components/Formloader/Formloader"
// import "./Login.css";
// import { forgotPassword, jwttoken } from '../../Store/User/UserAction';
// import {
//   TextField, MenuItem, Button, Dialog, IconButton,
//   DialogTitle, Checkbox, FormControlLabel,
//   DialogContent, DialogActions, Typography, FormHelperText
// } from '@mui/material';
// import CustomButton from '../../Components/Buttons/CustomButton';
// import CustomTextField from '../../Components/TextField/TextField';
//  import CloseIcon from '@mui/icons-material/Close';
// import LinkItem from '../../Components/LinkItem/linkitem';


// const Login = () => {
//   const [formData, setFormData] = useState({
//     emailid: "",
//     password: "",
//     userrole: "",
//   });
//   const [loading, setLoading] = useState(false);
//   const [orgLoading, setOrgLoading] = useState(false);
//   const [keepSignedIn, setKeepSignedIn] = useState(false);
//   const [openDialog, setOpenDialog] = useState(false);
//   const [forgotPasswordData, setForgotPasswordData] = useState({
//     email: "",
//     userrole: ""
//   });

//   const Form = withTheme(MuiTheme);
//   const schema = require("./schema.json");
//   const uiSchema = {
//     email: {
//       "ui:widget": "email",
//     },
//     password: {
//       "ui:widget": "password",
//     },
//   };

//   const handleForgotPasswordOpen = () => {
//     setOpenDialog(true);
//   };

//   const handleForgotPasswordClose = () => {
//     setOpenDialog(false);
//   };

//   const onSubmit = async (data) => {
//     console.log(data.formData);
//     await jwttoken(data.formData);
//   };

//   const onChange = ({ formData }) => {
//     console.log({ formData }, 'form')
//     setFormData(formData);
//   };
//   const handlePasswordResetSubmit = async (data) => {
//     console.log(data, 'forgotPassword');
//     await forgotPassword(data)
//     // Handle password reset logic here
//     setOpenDialog(false)
//   };

//   const handleForgotPasswordChange = (e) => {
//     const { name, value } = e.target;
//     setForgotPasswordData(prevState => ({ ...prevState, [name]: value }));
//   };

//   const handleKeepSignedInChange = (event) => {
//     setKeepSignedIn(event.target.checked);
//   };


//   return (
//     <>
//       {loading ? <FormLoader /> : ""}
//       <div style={{ display: "flex", flexDirection: "column" }}>
//         <h4>Log in to your account to access Intain ABS</h4>
//         <div className="form_row_single" >
//           {orgLoading ? (
//             <>
//               <FormLoader></FormLoader>
//               <p className='loading_text'>Loading,Please wait...</p>
//             </>
//           ) : (
//             <Form
//               formData={formData}
//               schema={schema}
//               uiSchema={uiSchema}
//               onChange={onChange}
//               onSubmit={onSubmit}
//               widgets={widgets}
//               FieldTemplate={CustomFieldTemplate}
//             >


//               <div id='form-btn'>
//                 <div className="container-fluid" style={{ textAlign: 'center' }}>
//                   <div className="row">
//                     <Button
//                       className="col-md-12"
//                       variant="contained"
//                       size="large"
//                       color="primary"
//                       style={{ background: '#048c88' }}
//                       id="signinbutton"
//                       type="submit"
//                     // disabled={this.state.loading === true ? true : false}

//                     >

//                       Sign in
//                     </Button>
//                   </div>
//                   <div className="forgot-password-container">
//                     <div
//                       type="button"
//                       onClick={handleForgotPasswordOpen}
//                       className="login-sign_up-links"
//                     >
//                       Forgot Password?
//                     </div>

//                     {/* <Link to={''} className="login-sign_up-links" onClick={this.onOpenModal.bind(this)}>Forgot Password?</Link> */}
//                   </div>

//                 </div>
//               </div>
//             </Form>
//           )}
//         </div>
//         <FormControlLabel
//           control={
//             <Checkbox
//               checked={keepSignedIn}
//               onChange={handleKeepSignedInChange}
//               color="primary"
//             />
//           }
//           label="Keep me signed-in"
//         />
//         <div style={{ display: 'flex', alignItems: 'center', marginTop: '35px' }}>
//           <hr style={{ flex: 1, border: '1px solid #ccc', marginRight: '8px' }} />
//           <Typography variant="body2" color="textSecondary" style={{ whiteSpace: 'nowrap' }}>
//             New to Intain ABS?
//           </Typography>
//           <hr style={{ flex: 1, border: '1px solid #ccc', marginLeft: '8px' }} />
//         </div>

//         <LinkItem
//           to={"/register"}
//           variant="contained"
//           className="loginBtn"
//           title={"Create your Account"}
//         >
//         </LinkItem>
//         <Dialog open={openDialog} onClose={handleForgotPasswordClose} className='modalPopup'>
//           <div >
//             <h2>Forgot Password</h2>
//             <>

//               <IconButton
//                 edge="end"
//                 color="inherit"
//                 onClick={handleForgotPasswordClose}
//                 aria-label="close"
//                 style={{ position: 'absolute', right: 16, top: 8, color: "#018e82" }}
//               >
//                 <CloseIcon />
//               </IconButton>
//             </>
//             <DialogContent>
//               <Typography variant="body1" gutterBottom>
//                 Confirm your Mail ID
//               </Typography>
//               <Typography variant="body2" gutterBottom>
//                 We will send the link to reset your password on your registered mail ID
//               </Typography>
//               <TextField
//                 label="Email Address"
//                 name="email"
//                 value={forgotPasswordData.email}
//                 onChange={handleForgotPasswordChange}
//                 fullWidth
//                 margin="normal"
//               />
//               <TextField
//                 label="User Role"
//                 name="userrole"
//                 value={forgotPasswordData.userrole}
//                 onChange={handleForgotPasswordChange}
//                 select
//                 fullWidth
//                 margin="normal"
//               >
//                 <MenuItem value="admin">Admin</MenuItem>
//                 <MenuItem value="processor">Processor</MenuItem>
//               </TextField>
//             </DialogContent>
//             <DialogActions>
//               <Button className='popupcancelbtn' onClick={handleForgotPasswordClose} color="primary" variant='outlined'>
//                 Cancel
//               </Button>
//               <CustomButton
//                 variant="contained"
//                 color="primary"
//                 onClick={handlePasswordResetSubmit}
//               >
//                 Confirm
//               </CustomButton>
//             </DialogActions>
//           </div>
//         </Dialog>

//       </div>
//     </>

//   )
// }

// export default Login


