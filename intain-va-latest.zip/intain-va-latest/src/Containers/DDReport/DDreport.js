import React, { useEffect, useState, useCallback } from 'react';
import Header from '../../Components/Header/Header';
import { ReportProblemOutlined, Search } from '@material-ui/icons';
import { Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Select, MenuItem, Chip, InputLabel, FormControl, Tooltip, Checkbox, CircularProgress } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { getattributedetailbypoolid, viewloans, reviewdata, downloadexcel, exportexcel, editloans, ddreportselect, addsignature, issuecertificate, getallmessagesbydealname, savecertificate } from '../../Store/ProcessorDashboard/ProcessorDashboardAction';
import MUIDataTable from 'mui-datatables';
import Match from "../../images/match.png";
import Mismatch from "../../images/mismatch.png";
import { Close } from '@material-ui/icons';
import CompareData from './CompareData';
import Loader from '../../Components/Loader/Loader';
import $ from "jquery";
import { useLocation } from 'react-router-dom';
import { useHistory } from 'react-router-dom';


const DDreport = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const history = useHistory();
  const ddreportdata = useSelector((state) => state.processordashboard.view_loans);
  const getddreportattribute = useSelector((state) => state.processordashboard.get_attribute_detail) || [];
  const getallmessage = useSelector((state) => state.processordashboard.getallmessage);
  const responsee = useSelector((state) => state.processordashboard.edit_loans);

  const [poolname, setPoolName] = useState();
  const [poolid, setPoolId] = useState();
  const [lmsfile, setLmsFile] = useState();
  const [contractfile, setContractFile] = useState();
  const [loandata, setLoanData] = useState(null);
  const [tabledata, setTableData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState([]);
  const [search, setSearch] = useState('');
  const [datafilter, setDataFilter] = useState();
  const [exportdata, setExportData] = useState();
  const [openreview, setOpenReview] = useState(false);
  const [editedloanid, setEditedLoanId] = useState("");
  const [msgdata, setMsgData] = useState();
  const [editloan, setEditLoan] = useState(null);
  const [opensign, setOpenSign] = useState(false);
  const [openreport, setOpenReport] = useState(false);
  const [certifydata, setCertifyData] = useState([]);
  const [address, setAddress] = useState([]);
  const [signatory, setSignatory] = useState([]);
  const [exportdataxl, setExportdataxl] = useState([]);
  const [sort, setSort] = useState([]);
  const [certifystatus, setCertifyStatus] = useState();
  const [formloader, setFormLoader] = useState();
  const [file1, setFile1] = useState("");
  const [filename1, setFileName1] = useState("");
  const [rowsselected, setRowsSelected] = useState();
  const [certifyDisabled, setCertifyDisabled] = useState(true);
  const [getdata, setGetData] = useState(false);
  const [getdata1, setGetData1] = useState(false);




  let filename = localStorage.getItem('filename');


  const selectedpoolid = async (selected) => {
    const arr = [];
    const arr1 = [];
    setSelected({ selected });
    if (selected.length > 0) {
      setCertifyDisabled(false);
    } else {
      setCertifyDisabled(true);
    }
    for (var i = 0; i < selected.length; i++) {
      var j = selected[j];
      let loanData = tabledata[j];
      arr.push(loanData);
      arr1.push(tabledata)
      dispatch(ddreportselect(JSON.stringify(arr)));
    }
  }

  const onRowsSelect = (rowsSelected, allRows) => {
    const selected = allRows.map((row) => row.dataIndex);
    setRowsSelected(selected);
    console.log("selected: ", selected);
    selectedpoolid(selected);
  };

  const backBtn = () => {
    history.push({
      pathname: "/processor/dashboard",
    });
  }
  const onSubmit = () => {
    let flag = 0;
    for (var i = 0; i < selected.length; i++) {
      var j = selected[i];
      let loanId = tabledata[j];
      if (loanId.matched == 0) {
        flag = 1;
        break;
      }
    }
    if (flag == 1) {
      setOpenReport(true);

    } else {
      console.log('finall')
    }

    setOpenSign(true);
    GetAllMessagesByDealName();
    setGetData(true);
  }

  const GetAllMessagesByDealName = async () => {
    // setLoading(true);
    var data = {
      dealName: poolname,
    }

    await dispatch(getallmessagesbydealname(data));
    let exportdata = [];
    console.log(tabledata, 'tabledataa')
    tabledata.map((data) => {
      let dupjson = {};
      Object.keys(data.lmsloan).map((value) => {
        dupjson[value] = data.lmsloan[value];
      });
      console.log("datanumber of pages", typeof data.NumberofPagesProcessed);

      let ababa1 = "Number of pages processed";
      dupjson[ababa1] = data.NumberofPagesProcessed;
      Object.keys(data.lmsloan).map((value) => {

        dupjson[value + " "] =
          data.attributewise_matched[value] === 1 ? "YES" : "NO";
      });
      dupjson["Exceptions"] = data.matched === 1 ? "NO" : "YES";
      exportdata.push(dupjson);

    });
    console.log(exportdata, "exportdataa")
    setExportdataxl(exportdata);

    if (getallmessage.statuscode === 200) {

      if (Array.isArray(getallmessage.result)) {
        let signatory = getallmessage.result.filter((value) => {
          return value.messageType === "Signatory";
        })
        let address = getallmessage.result.filter((value) => {
          return value.messageType === "Address";
        });
        let message = getallmessage.result.filter((value) => {
          return value.messageType === "Message";
        });
        const sorting = [...message].sort(
          (a, b) => a.messageNumber - b.messageNumber
        );
        setSort(sorting);
        setCertifyData(getallmessage.result);
        setAddress(address);
        setSignatory(signatory);
        // setLoading(false);

      } else {
        console.log('error');
        setLoading(false);
      }
    }
    else {
      alert('error')
    }
  }

  const handleOnChange1 = (e) => {
    setFile1(e.target.files[0])
    setFileName1(e.target.files[0].name);
    console.log("eeee", e.target.files[0].name, file1);

  };
  const onAddSignature = async () => {
    let data = new FormData();
    data.append("filename", file1);
    await dispatch(addsignature(data))
    setCertifyStatus(true);
  }
  const Certify = () => {
    const data = $("#pdfdata").html();
    console.log("dataaaaa", JSON.stringify(data));

    issueCertificate(data)
  }
  const issueCertificate = async (value) => {
    var data = {
      poolID: poolid,
      data: JSON.stringify(value),
    }

    await dispatch(issuecertificate(data));
    await saveCertificate();
    // window.location.assign('/processor/dashboard')



  }
  const saveCertificate = async (value) => {

    var data = {
      dealId: poolid,
      filePath: filename
    }
    console.log(data, "storee")

    await dispatch(savecertificate(data))
  }

  const tableData = (tableData1) => {
    console.log(tableData1, "tttt");

    // Check if tableData1 is undefined or not an array
    if (!Array.isArray(tableData1) || tableData1.length === 0) {
      return <></>; // Return an empty fragment if there's no data
    }

    const heading = Object.keys(tableData1[0]);

    return (
      <div className="span-class-scheduled">
        <table className="table-servicer">
          <thead>
            <tr>
              {heading.map((head) => (
                <th key={head} className="servicer-data-table-heading">
                  {head}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {tableData1.map((data, rowIndex) => (
              <tr key={rowIndex}>
                {heading.map((e, colIndex) => (
                  <td key={colIndex}>
                    {data[e]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const childHandler = (dataFromChild) => {
    if (dataFromChild.close === true) {
      setOpenReview(false);
    }
    if (dataFromChild.reload === true) {
      console.log('reloadedd')
      editLoans();
    }
  }

  const editLoans = async () => {
    var data = {
      edited_loanid: editedloanid,
      poolid: poolid,
      poolname: poolname,
    };
    await dispatch(editloans(data));
  };
  const ExportExcel = async () => {
    if (search === "") {
      let exportdata = [];
      tabledata.map((data) => {
        let dupjson = {};
        Object.keys(data.lmsloan).map((value) => {
          dupjson[value] = data.lmsloan[value];
        });
        Object.keys(data.lmsloan).map((value) => {
          dupjson[value + " "] =
            data.attributewise_matched[value] === 1 ? "YES" : "NO";
        });
        dupjson["Exceptions"] = data.matched === 1 ? "NO" : "YES";
        exportdata.push(dupjson);

      });


      var dealid = JSON.parse(localStorage.getItem('dealids'));
      let data = {
        dealid: dealid,
        poolname: poolname,
        poolid: poolid
      }

      await dispatch(exportexcel(data))
    } else {
      let exportdata = [];
      datafilter.map((data) => {
        let dupjson = {};
        Object.keys(data.lmsloan).map((value) => {
          dupjson[value + " "] =
            data.attributewise_matched[value] === 1 ? "YES" : "NO";

        });
        dupjson["Exceptions"] = data.matched === 1 ? "NO" : "YES";
        exportdata.push(dupjson);
      });
      setExportData(exportdata);
      var dealid = JSON.parse(localStorage.getItem('dealids'));
      let data = {
        dealid: dealid,
        poolname: poolname,
        poolid: poolid
      }
      await dispatch(exportexcel(data))
    }
  }
  const openReview = (value, loandocpath) => {
    console.log("hiii")
    console.log({ value, loandocpath }, "valueee")
    setEditedLoanId(value);
    setMsgData(value);

    // Use a callback to ensure loandata is updated
    setLoanData(prevData => {
      const loandataarray = Array.isArray(prevData) ? prevData : [];
      console.log('Updated Loan Data in openReview:', loandataarray);
      let result = loandataarray.find(e => e["Deal Id"] === value);
      const updatedLoanData = { ...result, loandocpath };
      console.log(JSON.stringify(updatedLoanData), 'result');
      dispatch(reviewdata(JSON.stringify(updatedLoanData)));
      setEditLoan(value);
      setOpenReview(true);
      return prevData;
    });
  }

  const prepareColumns = (loanData) => {
    let display = [];

    getddreportattribute.forEach((value) => {
      console.log(loanData, 'tablee')
      if (loanData[0]?.lmsloan) {
        Object.keys(loanData[0].lmsloan).forEach((val) => {
          console.log({ val, value }, "vallll")
          if (value.attributeName.toLowerCase().replace(/ /g, "") === val.toLowerCase().replace(/ /g, "")) {
            display.push({
              name: "lmsloan",
              label: value.attributeName,
              options: {
                filter: true,
                sort: true,
                customBodyRender: (value) => <>{value[val]}</>,
              },
            });
          }
        });
      }
    });

    const additionalColumns = [
      {
        name: "NumberofPagesProcessed",
        label: "Pages Processed",
        options: {
          filter: true,
          sort: true,
        },
      },
      {
        name: "matched",
        label: "Match / Mismatch",
        options: {
          filter: false,
          sort: false,
          customBodyRender: (value) => (
            <div style={{ textAlign: "center" }}>
              {value === 1 ? <img alt="" src={Match} /> : <img alt="" src={Mismatch} />}
            </div>
          ),
        },
      },
      {
        name: "agreementloan",
        label: "Action",
        options: {
          filter: false,
          sort: false,
          customBodyRender: (value, tableMeta) => (
            <Button
              variant="outlined"
              id="optionalbutton"
              type="submit"
              style={{ maxWidth: "5rem", padding: '1rem' }}
              onClick={(e) => {

                openReview(
                  value["Deal Id"] ||
                  value["APP_ID"] ||
                  value["Unique Identifier / Filename"] ||
                  value["Contract #"] ||
                  value["Unique Identifier"] ||
                  value["DOCUMENT_ID"] ||
                  value[
                  "Identifier (9 digit unique identifier)"
                  ] ||
                  value["Document ID"],
                  tableMeta.rowData.filter(
                    (e) =>
                      (typeof e === "string" &&
                        e.includes(".pdf")) ||
                      (typeof e === "string" &&
                        e.toLowerCase().endsWith(".pdf"))
                  )[0]
                )
              }}
            >
              Review
            </Button>
          ),
        },
      },
      {
        // 12
        name: "loandocpath",
        label: "loandocpath",
        options: {
          display: false,
          customBodyRender: (value, tableMeta, updateValue) => {
            return (
              <React.Fragment>
                <div className="">{value}</div>
              </React.Fragment>
            );
          },
        },
      }
    ];

    display = [...display, ...additionalColumns];
    console.log(display, "disp")
    setColumns(display);
  };

  useEffect(() => {
    if (responsee?.res?.data.length > 0) {
      console.log('Response Data:', responsee.res.data);

      const updatedData = responsee.res.data;
      const existingData = loandata || [];

      const updatedTableData = existingData.map(existingItem => {
        const updatedItem = updatedData.find(item => item['Deal Id'] === existingItem['Deal Id']);
        return updatedItem ? updatedItem : existingItem;
      });

      console.log('Updated Table Data:', updatedTableData);

      setLoanData(updatedTableData);
      setTableData(updatedTableData.sort((a, b) => parseFloat(a.matched) - parseFloat(b.matched)));
    }
  }, [responsee]);




  useEffect(() => {
    const fetchLoans = async () => {
      setLoading(true);

      const poolid = localStorage.getItem("poolid");
      var data = {
        poolid: poolid
      }
      if (poolid) {
        await dispatch(viewloans(data));
        await dispatch(getattributedetailbypoolid(poolid));
      }
      setLoading(false);
      setGetData1(true);
    };

    fetchLoans();
  }, [dispatch]);

  useEffect(() => {
    if (getdata1) {
      if (ddreportdata?.display_values) {
        setPoolId(ddreportdata.display_values.poolid);
        setPoolName(ddreportdata.display_values.poolname);
        setLmsFile(ddreportdata.display_values.lms_filename);
        setContractFile(ddreportdata.display_values.contract_filename);

        const poolIdFromData = ddreportdata.display_values.poolid;
        const loanData = ddreportdata?.data[0]?.[poolIdFromData]?.data;

        if (loanData && loanData.length > 0) {
          const sortedData = loanData.sort((a, b) => parseFloat(a.matched) - parseFloat(b.matched));
          console.log(sortedData, 'sortt');
          setTableData(sortedData);
          setLoanData(loanData);
          localStorage.setItem('dealids', JSON.stringify(ddreportdata.data[0][poolIdFromData]?.dealids));
          prepareColumns(sortedData);
        }
      }
    }
  }, [ddreportdata, getdata1]);


  // if (loading) {
  //   return (
  //     <React.Fragment>
  //     <img
  //       src={BeanEater}
  //       style={{
  //         width: "7vw",
  //         height: "9vh",
  //         backgroundColor: "transparent",
  //       }}
  //     />
  //     <h3 className="dot-loader">Loading.Please wait</h3>
  //   </React.Fragment>
  //   )

  // }
  const options = {
    customToolbar: () => {
      return (
        <div>
          <Button
            variant="contained"
            color="primary"
            onClick={async () => {
              await dispatch(downloadexcel(poolid, poolname));
            }}
            style={{ marginRight: "1rem" }}>
            Export LMS Excel
          </Button>
          <Button variant="contained" color="primary" onClick={ExportExcel}

          >
            EXPORT RECON
          </Button>
        </div>

      );
    },
    filterType: "dropdown",
    filter: false,
    search: false,
    print: false,
    viewColumns: false,
    download: false,
    rowHover: false,
    selectableRowsOnClick: false,
    selectToolbarPlacement: "none",
    selectableRows: true,
    onRowsSelect: onRowsSelect,
    textLabels: {
      body: {
        noMatch: loading === true ? (
          <Loader msg={"Please wait, Loading Loan Data"} />
        ) : (
          "Sorry, there is no matching data to display"
        ),
      },
    },
  }

  return (
    <div className="page">
      <div className="content">
        <div className="header">
          <Header pageTitle={"DD REPORT SCREEN"}></Header>
        </div>
        <div className='dealdata'>

          <div style={{ marginLeft: "1rem" }}>
            <div>Deal Name: {poolname}</div>
            <div>Deal ID: {poolid} </div>
          </div>
          <div>
            {" "}
            <div>LMS File:{lmsfile}</div>
            <div>Zip File:{contractfile} </div>
          </div>
        </div>
        <div className='page-content'>
          <MUIDataTable
            title={poolname}
            data={tabledata}
            columns={columns}
            options={options}
          />
        </div>
        <div className="navbarSteps navbarStepsBtm">
          <div className="row justify-content-end">
            <Button
              variant="outlined"
              id="optionalbutton"
              onClick={backBtn}
              sx={{ color: "#048c88 !important", borderColor: "#048c88 !important" }}

            >
              {" "}
              BACK{" "}
            </Button>

            <Button
              // onClick={this.onSubmit}
              variant="contained"
              color="primary"
              type="submit"
              // sx={{ color: "#048c88 !important" }}
              disabled={certifyDisabled}
              onClick={onSubmit}
            >

              CERTIFY
            </Button>
          </div>
        </div>
      </div>
      <>
        <Dialog open={openreview} onClose={() => setOpenReview(false)} className='modalPopup' maxWidth="lg" PaperProps={{
          style: {
            overflow: 'hidden', // Hides overflow
          },
        }} >
          <h2>Match Unmatch Data</h2>
          <Button
            className="closePopup"
            style={{ minWidth: "30px" }}
            variant="text"
            color="primary"
            onClick={() => setOpenReview(false)}
          >
            {" "}
            <Close></Close>

          </Button>
          <CompareData
            action={childHandler}
            msgData={msgdata}
          >

          </CompareData>
        </Dialog>
      </>
      <>
        <Dialog open={opensign} onClose={() => setOpenSign(false)} className='modalPopup' maxWidth="xl"

          PaperProps={{
            style: {
              overflow: 'hidden', // Hides overflow
            },
          }}

        >
          <h2>Upload Signature</h2>
          <Button
            className="closePopup"
            style={{ minWidth: "30px" }}
            variant="text"
            color="primary"
            onClick={() => setOpenSign(false)}
          >

            <Close></Close>

          </Button>
          <div className="form-container">
            <div className="kyc-card__button-container1">
              <div style={{ padding: "2rem" }}>
                <h6 className="e1class">Upload Signature</h6>
                <button
                  className="card__button"
                  style={{
                    position: "relative",
                  }}
                >
                  <label
                    htmlFor="icon-button-file-id2"
                    className="upload-button-label"
                  >
                    Select File
                  </label>
                  <input
                    required
                    id="icon-button-file-id2"
                    type="file"
                    accept="image/png, image/jpg, image/jpeg"
                    style={{
                      position: "absolute",
                      width: "60%",
                      height: "100%",
                      cursor: "pointer",
                      top: "0",
                      right: "0px",
                      opacity: "0",
                      border: "1.2px solid #212121",
                    }}
                    onChange={handleOnChange1}
                  />
                </button>
              </div>
              {file1 !== "" && (
                <div className="kyc-card__select_name-container">
                  <p>{filename1}</p>
                </div>
              )}
            </div>
            <div className="modalsubmit">
              <div className="submitbuttonbg">
                <div className="">
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "flex-end",
                    }}
                  >
                    <Button
                      variant="contained"
                      id="optionalbutton"
                    // onClick={this.onCloseModal3}
                    >
                      {" "}
                      CANCEL{" "}
                    </Button>
                    <Button
                      variant="contained"
                      color="primary"
                      type="submit"
                      onClick={onAddSignature}
                    >
                      Upload
                      {formloader === true ? (
                        <CircularProgress
                          size="22px"
                          color="primary"
                        />
                      ) : (
                        ""
                      )}
                    </Button>

                    {certifystatus === true ? (
                      <Button
                        variant="contained"
                        color="primary"
                        type="submit"
                        onClick={Certify}
                      >
                        {" "}
                        CERTIFY{" "}
                        {formloader === true ? (
                          <CircularProgress
                            size="22px"
                            color="primary"
                          />
                        ) : (
                          ""
                        )}
                      </Button>
                    ) : (
                      <Button
                        variant="contained"
                        color="primary"
                        type="submit"
                        disabled
                        onClick={Certify}
                      >
                        CERTIFY
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Dialog>
      </>

      <>
        {getdata && (
          <div id='pdfdata' hidden>
            <h4 className="certicate-heading">Certificate</h4>
            {address.map((value) => {
              var arr = value.messageBody.split(",").map((add) => (
                <div>
                  {add},<br />
                </div>
              ));
              return (
                <div className="certificate-para1">
                  <address>{arr}</address>
                </div>
              )
            })}

            <div className="certificate-para1">

              {sort.map((value) => {
                return (
                  <div className="certificate-para1">
                    {value.messageBody}
                  </div>
                )
              })}
            </div>
            {signatory.map((value) => {
              return (
                <div className="certificate-para1-right">

                  <h6>{value.messageBody}</h6>
                  <img
                    src={
                      "https://intainva.intainabs.com/" +
                      "root_folder/"
                      +
                      filename
                    }
                    alt="logo"
                    className="wellslogodeal"
                  />
                </div>
              )
            })}
            <h4 className="certicate-heading1">Exception Report</h4>
            <div>
              {exportdataxl === undefined ? (
                <></>
              ) : tableData(exportdataxl)}
              {/* exportdataxl */}
            </div>
          </div>
        )}
        {/* {getallmessage.result.length !== 0 ? (
          

        ) : null} */}
      </>
      <>
        <div >
          <Dialog open={openreport} onClose={() => setOpenReport(false)} >
            <div style={{ textAlign: "center" }}>
              <ReportProblemOutlined
                style={{ fontSize: "xxx-large" }}
              >
              </ReportProblemOutlined>
            </div>
            <div style={{ textAlign: "center" }}>
              <h5>
                Contracts have not been viewed for mismatch. Do you
                still want to proceed?
              </h5>
            </div>
            <div class="row p-3" style={{ textAlign: "center" }}>

              <div className="col-md-6">
                <Button
                  variant="outlined"
                  size="large"
                // onClick={this.onCloseModal1}
                >
                  No
                </Button>
              </div>
              <div className="col-md-6">
                <Button
                  variant="contained"
                  size="large"
                // onClick={this.onYes}
                >
                  Yes
                </Button>
              </div>
            </div>
          </Dialog>
        </div>
      </>
    </div>
  );
};

export default DDreport;