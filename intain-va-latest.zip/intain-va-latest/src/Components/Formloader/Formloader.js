import React from 'react';
import "../../App.css"
import { LinearProgress } from '@material-ui/core';

const FormLoader = () => {
    return (
        <div className="form-loader">
            <LinearProgress  color='secondary'/>
        </div>
    );
}

export default FormLoader;
